<?php
// +----------------------------------------------------------------------+
// | PHP version 5                                                        |
// +----------------------------------------------------------------------+
// | Mastered by (C) 2009 NoveOPiu di Enrico Possenti                     |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or        |
// | modify it under the terms of the GNU Lesser General Public           |
// | License as published by the Free Software Foundation; either         |
// | version 2.1 of the License, or (at your option) any later version.   |
// |                                                                      |
// | This library is distributed in the hope that it will be useful,      |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    |
// | Lesser General Public License for more details.                      |
// |                                                                      |
// | You should have received a copy of the GNU Lesser General Public     |
// | License along with this library; if not, write to the Free Software  |
// | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 |
// | USA, or view it online at http://www.gnu.org/licenses/lgpl.txt.      |
// +----------------------------------------------------------------------+
// | Authors: Enrico Possenti <info@noveopiu.com>                         |
// +----------------------------------------------------------------------+
//
// $Id: core.php,v 0.1.0 2009/06 $
/**
 * dCTL class provides a way to perform queries on an XML database of
 * dCTL-extended TEI encoded documents.
 *
 * To use this class you need to access a dCTL environment offering this kind
 * of webservice.
 * {@link http://www.ctl.sns.it/dctl/}
 *
 * @author Enrico Possenti <info@noveopiu.com>
 * @version $Revision: 0.1.0 $
 * @package dCTL-Engine
 */
	// |
	// +----------------------------------------------------------------------+
 // | this file is meant to be an include...
 if(empty($isInclude)){ echo "No direct access!!"; die();  }
 // | load config files
 require_once(str_replace('//','/',dirname(__FILE__).'/').'../_shared/config.inc.php');
 require_once(str_replace('//','/',dirname(__FILE__).'/').'./config.inc.php');
// +----------------------------------------------------------------------+
	// | MAIN CLASS DEFINITION
	// +----------------------------------------------------------------------+
	class dCTL {
		// | Declaration of private members
		protected static $_instance;
		protected $_xml_header;
		protected $_db;
		protected $_db_base_path;
		protected $_db_publish_path;
		protected $_fs_publish_path;
		protected $_use_private_db;
		protected $_debug;
		// +----------------------------------------------------------------------+
		// | INTERFACE TO THE CLASS
		// +----------------------------------------------------------------------+
		public function getStructure ($resourceList='') {
		 return $this->_get_resource (true, $resourceList);
		}
		// +----------------------------------------------------------------------+
		public function getBlock ($resourceList='') {
		 return $this->_get_resource (false, $resourceList);
		}
		// +----------------------------------------------------------------------+
		public function getOptions ($resourceList='', $xpath='') {
  	// wraps results
   return $this->_resources_to_xml($this->_get_resource (true, $resourceList, true, $xpath));
		}
		// +----------------------------------------------------------------------+
		public function getLinks ($resourceList='', $kind='') {
		 return '<dctl><stub>UNIMPLEMENTED '.__METHOD__.', JUST A STUB TO CATCH CALLS...</stub></dctl>';
		}
		// +----------------------------------------------------------------------+
		public function getAuthorityName () {
		 return '<dctl><stub>UNIMPLEMENTED '.__METHOD__.', JUST A STUB TO CATCH CALLS...</stub></dctl>';
		}
		// +----------------------------------------------------------------------+
		public function getAuthorityIconclass () {
		 return '<dctl><stub>UNIMPLEMENTED '.__METHOD__.', JUST A STUB TO CATCH CALLS...</stub></dctl>';
		}
  // +----------------------------------------------------------------------+
		public static function singleton () {
			if (! isset(self::$_instance)) {
				$c = __CLASS__;
				self::$_instance = new $c;
				};
			return self::$_instance;
		}
		// +----------------------------------------------------------------------+
		protected function __autoload() {
			// | Autoload of the class definition
			// | not yet implemented
		}
		// +----------------------------------------------------------------------+
		protected function __construct() {
			// | private & protected
			$this->_xml_header = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
			require_once(str_replace('//','/',dirname(__FILE__).'/')."../_shared/exist_api.inc.php");
			$this->_db = dctl_xmldb_connect();
			$this->_db_base_path = DB_PATH_SEPARATOR.'db'.DB_PATH_SEPARATOR;
			$this->_db_publish_path = '';
			$this->_fs_publish_path = '';
			// | public
			$this->_use_private_db = false;
			$this->_debug = false;
			// | initialize
			$this->_set_archive_to_use();
   if (is_file($this->_fs_publish_path.DCTL_TEXTCLASS)) $this->_TEXTCLASS = loadXML($this->_fs_publish_path.DCTL_TEXTCLASS);
		}
		// +----------------------------------------------------------------------+
		public function __set($name='', $value='') {
		 switch($name) {
		  case 'use_private_db':
		  case 'debug':
					$name = '_'.$name;
					$oldValue = $this->$name;
					$this->$name = $value;
					if ($oldValue != $value) {
						switch ($name) {
							case '_use_private_db':
								$this->_set_archive_to_use();
								if (is_file($this->_fs_publish_path.DCTL_TEXTCLASS)) $this->_TEXTCLASS = loadXML($this->_fs_publish_path.DCTL_TEXTCLASS);
							break;
							case '_debug':
								if (!defined('DCTL_USER_KIND')) define('DCTL_USER_KIND', 0);
							 if ($value) {
									if (!defined('DCTL_USER_GURU')) define('DCTL_USER_GURU', DCTL_USER_KIND);
								} else {
									DEFINE('DCTL_USER_GURU', -1);
								};
							break;
						};
					};
		   break;
		  default:
		   return '<dctl><stub>UNACCESSIBLE '.strtoupper($name).'...</stub></dctl>';
		   break;
		 };
		}
		// +----------------------------------------------------------------------+
		public function __get($name='') {
		 switch($name) {
		  case 'use_private_db':
		  case 'debug':
					$name = '_'.$name;
  			return $this->$name;
		   break;
		  default:
		   return '<dctl><stub>UNACCESSIBLE '.strtoupper($name).'...</stub></dctl>';
		   break;
			};
		}
		// +----------------------------------------------------------------------+
		public function __toString() {
			// | not yet implemented
				return 'This set of classes allows to query the dCTL-Engine';
		}
		// +----------------------------------------------------------------------+
		public function __clone () {
			trigger_error('Clone is not allowed.', E_USER_ERROR);
		}
		// +----------------------------------------------------------------------+
		protected function _set_archive_to_use() {
		 $this->_db_publish_path = $this->_db_base_path. (($this->_use_private_db) ? 'dctl-temp' : 'dctl-pub').DB_PATH_SEPARATOR;
   $this->_fs_publish_path = str_ireplace(DCTL_DBBASE, (($this->_use_private_db) ? 'dctl-temp' : 'dctl-pub').SYS_PATH_SEPARATOR, DCTL_PUBLISH);
  }
		// +----------------------------------------------------------------------+
		protected function _get_collection_list($justRefs=false, $thePath='', &$collectionList, $withEmpty=false) {
			// | Returns a list of records describing a collection
			$collectionList = array();
			if ($thePath != '') {
				$collectionRecord = array();
				if ($collections = $this->_db->getCollections($thePath)) {
					foreach ((array) $collections->collections->elements as $key=>$collection) {
						$thePath2 = $thePath.$collection.DB_PATH_SEPARATOR;
						$this->_get_collection_record ($justRefs, $thePath2, &$collectionRecord);
      $collectionList[$key]['kind'] = 'collection';
						$collectionList[$key]['ref'] = $collectionRecord['ref'];
						$collectionList[$key]['path'] = $collectionRecord['path'];
						$collectionList[$key]['short'] = $collectionRecord['short'];
						if (! $justRefs) {
							$collectionList[$key]['id'] = $collectionRecord['id'];
							$collectionList[$key]['full'] = $collectionRecord['full'];
							$collectionList[$key]['desc'] = $collectionRecord['desc'];
							$collectionList[$key]['packages'] = $collectionRecord['packages'];
						};
					};
					asort($collectionList);
				};
			};
		}
		// +----------------------------------------------------------------------+
		protected function _get_collection_record ($justRefs=false, $thePath='', &$collectionRecord, $filter= array()) {
			// | Returns a record for the resource:
			// | 'kind'     : framework's kind of resource (collection)
			// | 'id'       : user defined mnemonic identifier
			// | 'ref'      : framework's unique identifier, must be used as a reference to the resource
			// | 'path'     : framework's unique path to the resource in the xmldb
			// | 'short'    : user defined short mnemonic identifier
			// | 'full'     : framework's composite identifier
			// | 'desc'     : user defined description
			// | 'packages' : list of package resources
			$collectionRecord = array();
			$collectionRecord['kind'] = '';
			$collectionRecord['ref'] = '';
			$collectionRecord['path'] = '';
			$collectionRecord['short'] = '';
			if (! $justRefs) {
				$collectionRecord['id'] = '';
				$collectionRecord['full'] = '';
				$collectionRecord['desc'] = '';
			};
			$collectionRecord['packages'] = array();
			$collection_id = basename($thePath);
   if ($collection_id != '') {
				$xml_resource = $thePath.$collection_id.DCTL_RESERVED_INFIX.DCTL_RESERVED_PREFIX.$collection_id.'.xml';
				$xquery = DCTL_XQUERY_BASE;
				$xquery .= ' let $node := doc("'.$xml_resource.'")/tei:TEI ';
				$xquery .= ' return ';
				$xquery .= ' <node';
				$xquery .= ' ref="{$node/@xml:id}"';
				$xquery .= ' short="{$node/tei:teiHeader/tei:encodingDesc/tei:projectDesc/tei:p[@n=\'short\']}"';
				if (! $justRefs) {
					$xquery .= ' id="{$node/tei:teiHeader/tei:encodingDesc/tei:projectDesc/tei:p[@n=\'id\']}"';
					$xquery .= ' desc="{$node/@n}"';
				};
				$xquery .= '> ';
				$xquery .= ' </node> ';
				if ($result = $this->_db->xquery($xquery)) {
					$resultXML = (array) $result["XML"];
					foreach ($resultXML as $node) {
						$xml_node = $node;
						$xml_node = simplexml_load_string($xml_node, 'SimpleXMLElement', DCTL_XML_LOADER);
						$namespaces = $xml_node->getDocNamespaces();
						foreach ($namespaces as $nsk=>$ns) {
							if ($nsk == '') $nsk = 'tei';
							$xml_node->registerXPathNamespace($nsk, $ns);
						};
						if ((string)$xml_node['ref'] != '') {
							$collectionRecord['kind'] = 'collection';
							$collectionRecord['ref'] = 'xml://'.(string)$xml_node['ref'];
							$collectionRecord['path'] = $xml_resource;
							$collectionRecord['short'] = (string)$xml_node['short'];
							if (! $justRefs) {
								$collectionRecord['id'] = (string)$xml_node['id'];
								$collectionRecord['full'] = cleanWebstring($collectionRecord['id'].': '.$collectionRecord['short'], FIELD_STRING_LENGTH).SYS_DBL_SPACE;
								$collectionRecord['desc'] = (string)$xml_node['desc'];
							};
							$this->_get_package_list($justRefs, $thePath, &$collectionRecord['packages'], $filter);
						};
					};
				};
			};
		}
		// +----------------------------------------------------------------------+
		protected function _get_package_list($justRefs=false, $thePath='', &$packageList, $filter=array(), $withEmpty=false, $sortBy='date') {
			// | Returns a list of records describing a package
			if (! is_array($filter)) $filter = (array) $filter;
			$packageList = array();
			if ($thePath != '') {
    $packageRecord = array();
				if ($packages = $this->_db->getCollections($thePath)) {
					foreach ((array) $packages->resources->elements as $key=>$package) {
						$package_id = explode(DCTL_RESERVED_INFIX, $package);
						$collection_id = $package_id[0];
						$package_id = $package_id[1];
						if($package_id[0] != DCTL_RESERVED_PREFIX) {
							$name = substr($package_id, 0,4);
							$ext = substr($package_id, -8,4);
       if ((count($filter)==0) || (in_array($ext, $filter)) || (preg_grep('/'.$name.'/', $filter))) {
        $thePath2 = $thePath.DB_PATH_SEPARATOR.$package;
								$this->_get_package_record ($justRefs, $thePath2, &$packageRecord);
								$packageList[$key]['kind'] = 'package';
								$packageList[$key]['ref'] = $packageRecord['ref'];
								$packageList[$key]['path'] = $packageRecord['path'];
								$packageList[$key]['short'] = $packageRecord['short'];
								$packageList[$key]['type'] = $packageRecord['type'];
								$packageList[$key]['date'] = $packageRecord['date'];
								$packageList[$key]['collection_ref'] = $packageRecord['collection_ref'];
								if (! $justRefs) {
									$packageList[$key]['id'] = $packageRecord['id'];
									$packageList[$key]['full'] = $packageRecord['full'];
									$packageList[$key]['desc'] = $packageRecord['desc'];
									$packageList[$key]['collection'] = $packageRecord['collection'];
									$packageList[$key]['author'] = $packageRecord['author'];
									$packageList[$key]['title'] = $packageRecord['title'];
									$packageList[$key]['publisher'] = $packageRecord['publisher'];
								};
							};
						};
					};
				//  asort($packageList);
					$docx = array();
					$packageList2 = array();
					foreach($packageList as $k=>$package) {
						$packageList2[$package['ref']] = $package[$sortBy];
					};
					asort($packageList2);
					foreach($packageList2 as $packRef=>$dummy) {
						foreach ($packageList as $key=>$package) {
							if ($package['ref'] == $packRef) $docx[$key] = $package;
						};
					};
					$packageList = $docx;
				};
			};
		}
		// +----------------------------------------------------------------------+
		protected function _get_package_record ($justRefs=false, $thePath='', &$packageRecord) {
			// | Returns a record for the resource:
			// | 'kind'           : framework's kind of resource (package)
			// | 'id'             : user defined mnemonic identifier
			// | 'ref'            : framework's unique identifier, must be used as a reference to the resource
			// | 'path'           : framework's unique path to the resource in the xmldb
			// | 'short'          : user defined short mnemonic identifier
			// | 'full'           : framework's composite identifier
			// | 'desc'           : user defined description
			// | 'collection_ref' : framework's unique identifier, must be used as a reference to the resource
			// | 'collection'     : user defined mnemonic identifier
			// | 'type'           : framework's type of resource
			// | 'author'         : <teiHeader> field
			// | 'title'          : <teiHeader> field
			// | 'publisher'      : <teiHeader> field
			// | 'date'           : <teiHeader> field
			$packageRecord = array();
			$packageRecord['kind'] = '';
			$packageRecord['ref'] = '';
			$packageRecord['path'] = '';
			$packageRecord['short'] = '';
			$packageRecord['type'] = '';
			$packageRecord['date'] = '';
			$packageRecord['collection_ref'] = '';
			if (! $justRefs) {
				$packageRecord['id'] = '';
				$packageRecord['full'] = '';
				$packageRecord['desc'] = '';
				$packageRecord['collection'] = '';
				$packageRecord['author'] = '';
				$packageRecord['title'] = '';
				$packageRecord['publisher'] = '';
			};
			$package_id = basename($thePath);
			$package_id = explode(DCTL_RESERVED_INFIX, $package_id);
			$collection_id = isset($package_id[0]) ? $package_id[0] : '';
			$package_id = isset($package_id[1]) ? $package_id[1] : '';
			if ($package_id != '') {
				$thePath = dirname($thePath).DB_PATH_SEPARATOR;
				$xml_resource = $thePath.$collection_id.DCTL_RESERVED_INFIX.$package_id;
				$ext = str_ireplace('.xml','', $package_id);
				$ext = substr($ext, -4, 4);
				$xquery = DCTL_XQUERY_BASE;
				$xquery .= ' let $node := doc("'.$xml_resource.'")/tei:TEI ';
				$xquery .= ' return ';
				$xquery .= ' <node';
				$xquery .= ' ref="{$node/@xml:id}"';
				$xquery .= ' short="{$node/tei:teiHeader/tei:encodingDesc/tei:samplingDecl/tei:p[@n=\'short\']}"';
				$xquery .= ' type="'.$ext.'"';
				$xquery .= ' date="{$node/tei:teiHeader/tei:fileDesc/tei:sourceDesc/tei:biblFull[@n=\'source\']/tei:publicationStmt/tei:date}"';
				$xquery .= ' collection_ref="{$node/tei:teiHeader/tei:encodingDesc/tei:projectDesc/tei:p[@n=\'id\']}"';
				if (! $justRefs) {
					$xquery .= ' id="{$node/tei:teiHeader/tei:encodingDesc/tei:samplingDecl/tei:p[@n=\'id\']}"';
					$xquery .= ' collection="{$node/tei:teiHeader/tei:encodingDesc/tei:projectDesc/tei:p[@n=\'short\']}"';
					$xquery .= ' desc="{$node/@n}"';
					$xquery .= ' author="{$node/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:author}"';
					$xquery .= ' title="{$node/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:title[@type=\'main\']}"';
					$xquery .= ' publisher="{$node/tei:teiHeader/tei:fileDesc/tei:sourceDesc/tei:biblFull[@n=\'source\']/tei:publicationStmt/tei:publisher}"';
				};
				$xquery .= '> ';
				$xquery .= ' </node> ';
				if ($result = $this->_db->xquery($xquery)) {
					$resultXML = (array) $result["XML"];
					foreach ($resultXML as $node) {
						$xml_node = $node;
						$xml_node = simplexml_load_string($xml_node, 'SimpleXMLElement', DCTL_XML_LOADER);
						$namespaces = $xml_node->getDocNamespaces();
						foreach ($namespaces as $nsk=>$ns) {
							if ($nsk == '') $nsk = 'tei';
							$xml_node->registerXPathNamespace($nsk, $ns);
						};
						if ((string)$xml_node['ref'] != '') {
							$packageRecord['kind'] = 'package';
							$packageRecord['ref'] = 'xml://'.str_ireplace((string)$xml_node['collection_ref'].DCTL_RESERVED_INFIX, (string)$xml_node['collection_ref'].DB_PATH_SEPARATOR, (string)$xml_node['ref']);
							$packageRecord['path'] = $xml_resource;
							$packageRecord['short'] = (string)$xml_node['short'];
							$packageRecord['type'] = (string)$xml_node['type'];
							$packageRecord['date'] = (string)$xml_node['date'];
							$packageRecord['collection_ref'] = 'xml://'.(string)$xml_node['collection_ref'];
							if (! $justRefs) {
								$packageRecord['id'] = (string)$xml_node['id'];
								$packageRecord['full'] = cleanWebstring($packageRecord['id'].': '.$packageRecord['short'], FIELD_STRING_LENGTH).SYS_DBL_SPACE;
								$packageRecord['desc'] = (string)$xml_node['desc'];
								$packageRecord['collection'] = (string)$xml_node['collection'];
								$packageRecord['author'] = (string)$xml_node['author'];
								$packageRecord['title'] = (string)$xml_node['title'];
								$packageRecord['publisher'] = (string)$xml_node['publisher'];
							};
						};
					};
				};
			};
		}
		// +----------------------------------------------------------------------+
  protected function _parse_uri($resourceList='', $xpath='') {
			// | an array is needed
			if (! is_array($resourceList)) $resourceList = explode(',', $resourceList);
			$docList = array();
			foreach($resourceList as $k=>$resource) {
			 $resource = trim($resource).(($xpath != '') ? '?'.$xpath: '');
	 		// | force xml:// scheme if none present
			 if (! preg_match('/^(([^:\/?#]+):)/i', $resource)) {
			  $resource = 'xml://'.$resource;
			 };
//			 $resource = preg_replace('/\s/', '', $resource);
	 		// | parse URI
				$parsed = array();
				$preg_match = array();
				$parsed['source'] = $resource;
    if (preg_match('/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/i', $resource, $preg_match)) {
				 $parsed['scheme']    = isset($preg_match[2]) ? (($preg_match[2] != '') ? $preg_match[2] : '') : '';
				 $parsed['authority'] = isset($preg_match[4]) ? (($preg_match[4] != '') ? $preg_match[4].'/' : '') : '';
				 $parsed['path']      = isset($preg_match[5]) ? (($preg_match[5] != '') ? $preg_match[5].'/' : '') : '';
				 $parsed['query']     = isset($preg_match[7]) ? (($preg_match[7] != '') ? '?'.($preg_match[7]) : '') : '';
				 $parsed['anchor']    = isset($preg_match[9]) ? (($preg_match[9] != '') ? '#'.$preg_match[9] : '') : '';
					$parsed['uri'] = $parsed['scheme'].'://'.$parsed['authority'].$parsed['path'].$parsed['query'].$parsed['anchor'];
     switch ($parsed['scheme']) {
				  case 'xml':
				  case 'img': {
							$unwanted = '(\/$)*|(\*_+\*)*|(\*)*';
							$parsed['collection'] = preg_replace('/'.$unwanted.'/', '', $parsed['authority']);
							$parsed['package'] = preg_replace('/'.$unwanted.'/', '', $parsed['path']);
       $normalize = '';
							$normalize .= DB_PATH_SEPARATOR.str_ireplace(DCTL_RESERVED_INFIX, DB_PATH_SEPARATOR, $parsed['collection']).DB_PATH_SEPARATOR;
							$normalize .= str_ireplace(DCTL_RESERVED_INFIX, DB_PATH_SEPARATOR, $parsed['package']).DB_PATH_SEPARATOR;
							$normalize = str_ireplace(DB_PATH_SEPARATOR.DB_PATH_SEPARATOR, DB_PATH_SEPARATOR, $normalize);
							$rebuilt = array_filter(explode(DB_PATH_SEPARATOR, $normalize));
							$parsed['collection'] = isset($rebuilt[1]) ? $rebuilt[1] : '';
							$parsed['package'] = isset($rebuilt[2]) ? $rebuilt[2] : '';
							$parsed['locator'] = normalize(isset($rebuilt[3]) ? $rebuilt[3] : '');
							$parsed['locator'] = preg_replace('/\/$/', '', stripslashes($parsed['locator']));
							$parsed['query'] = preg_replace('/^\?/', '', stripslashes($parsed['query']));
							$parsed['anchor'] = preg_replace('/^\#/', '', stripslashes($parsed['anchor']));
				  };
				  break;
				  default:
				  break;
				 };
    };
			 $docList[$k] = $parsed;
			};
			return $docList;
		}
		// +----------------------------------------------------------------------+
		protected function _get_resource ($justRefs=false, $resourceList='', $asOptions=false, $xpath='') {
		 $resourceList = $this->_parse_uri($resourceList, $xpath);
			$docList = array();
			foreach($resourceList as $key4docList=>$parsed) {
    $resList = array();
				switch ($parsed['scheme']) {
					case 'xml':
					case 'img': {
						switch ($parsed['scheme']) {
							case 'xml': {
								if ($parsed['collection'] == '') {
									$this->_get_collection_list(false, $this->_db_publish_path, &$resList);
								} else {
									$xml_resource = $this->_db_publish_path.$parsed['collection'].DB_PATH_SEPARATOR;
									if ($parsed['package'] == '') {
										$this->_get_collection_record(false, $xml_resource, &$resList[]);
									} else {
										if (preg_match('/^(_\w{3})|(\w*_)$/',  $parsed['package'], $preg_match)) {
											$this->_get_package_list(false, $xml_resource, &$resList, $preg_match[0]);
          } else {
											$package = (preg_match('/\.xml$/i', $parsed['package']) ? $parsed['package'] : $parsed['package'].'.xml');
											$xml_resource .= $parsed['collection'].DCTL_RESERVED_INFIX.$package;
											$this->_get_package_record(false, $xml_resource, &$resList[]);
										};
									};
									if (($parsed['locator'] != '') || ($parsed['query'] != '') || ($parsed['anchor'] != '') || ($asOptions)) {
          $packageList = $resList;
										unset($resList);
										$resList = array();
 									foreach ($packageList as $key4package=>$package) {
											$xml_resource = $package['path'];
											$db_resource = '';
											$partial = false;
											$context = '';
											$context .= (($parsed['locator'] == '') & ($parsed['query'] == '')) ? '/' : '';
											$context .= ($parsed['locator'] != '') ? '/id("'.$parsed['locator'].'")' : '';
											$context .= ($parsed['query']) ? $parsed['query'] : '';
											$last_attr = '';
											$last_val = '';
											if (preg_match('/\@(\w+)\s*.?\s*=\s*"\s*(.*)\s*"\s*/', $context, $matches)) {
												$last_attr = $matches[count($matches)-2];
												$last_val = $matches[count($matches)-1];
											};
											$match = str_ireplace('*', '', $last_val);
											$tag = '';
											$absLevel = '';
											$startAt = '';
											$howMany = '';
											$upTo = '';
											$forced = false;
											$jolly = false;
											if ($asOptions) {
												if ($parsed['query'] != '') {
													if (preg_match('/^\s*\@\s*(\w+)\s*\&*\|*\s*\=\s*\".*\"\s*$/', $context, $matchesX) ) {
															$forced = true;
															$context = '//*['.$context.']';
													};
												};
	           switch (true) {
													case preg_match('/^\s*(\w*)\s*(\@\s*\"\s*((\w|\*)*)\s*(\+*)\s*(.*)\s*\"\s*(\;\s*(\-*\d+)\s*)?)/', $parsed['anchor'], $matches):
              $tag = isset($matches[1]) ? $matches[1] : $tag;
														$startAt = isset($matches[3]) ? $matches[3] : $startAt;
														$upTo = isset($matches[5]) ? (($matches[5] != '') ? $startAt : '') : '';
														$startAt = isset($matches[6]) ? $startAt.$matches[6] : $startAt;
														$howMany = ($startAt) ? 1 : $startAt;
														$howMany = isset($matches[8]) ? (($matches[8] != '') ? intval($matches[8]) : $howMany) : $howMany;
														if ($tag == '') $tag = $last_attr;
														$jolly = stripos($startAt, '*');
														if ($jolly !== false) {
														 $startAt = substr($startAt,0,$jolly);
														 $upTo = $startAt.'.';
														 if (!isset($matches[8])) $howMany = '';
														 ++$jolly;
														};
														$context .= '[lower-case(@'.$tag.') >= "'.strtolower($startAt).'"]';
														if ($upTo != '') $context .= '[matches(@'.$tag.', "^'.$upTo.'", "si")]';
														$context .= '/@'.$tag;
														$startAt = 1;
													break;
													default:
														if ($parsed['query'] != '') {
													 if ($forced) {
														  $context .= '/@'.$matchesX[1];
														 };
														} else {
															$context .= ($parsed['locator'] == '') ? 'tei:div[.//text()]' : '';
														};
													// $context = '/'.$context;
													break;
												};
											} else {
												switch (true) {
													case preg_match('/^(div)\s*(\-*\d+)/', $parsed['anchor'], $matches):
														$tag = isset($matches[1]) ? $matches[1] : $tag;
														$absLevel = isset($matches[2]) ? abs(strval($matches[2])) : '';
														$context .= '/ancestor-or-self::tei:'.$tag.'[count(ancestor::tei:'.$tag.')='.($absLevel-1).']';
													break;
													case preg_match('/^\s*(div)\s*($|\@\s*(\-*\d+)\s*(\;\s*(\-*\d+))?)/', $parsed['anchor'], $matches):
														$tag = isset($matches[1]) ? $matches[1] : $tag;
														$startAt =  isset($matches[3]) ? abs(intval($matches[3])) : $startAt;
														$howMany =  isset($matches[5]) ? intval($matches[5]) : (($startAt) ? 1 : $startAt);
														$context .= (($parsed['locator'] != '') | ($parsed['query'] != '')) ? '/' : '';
														$context .= 'tei:'.$tag;
													break;
													case preg_match('/^\s*(pb)\s*($|\@\s*(\-*\d+)\s*(\;\s*(\-*\d+))?)/', $parsed['anchor'], $matches):
														$tag = isset($matches[1]) ? $matches[1] : $tag;
														$startAt =  isset($matches[3]) ? abs(intval($matches[3])) : $startAt;
														$howMany =  isset($matches[5]) ? intval($matches[5]) : (($startAt) ? 1 : $startAt);
														$context .= (($parsed['locator'] != '') | ($parsed['query'] != '')) ? '/' : '';
														$context .= '/tei:'.$tag;
													break;
													default:
														if ($parsed['query'] != '') {
														} else {
															$context .= ($parsed['locator'] == '') ? 'tei:div[.//text()]' : '';
														};
													break;
												};
											};
											$xquery = '';
											if ($asOptions) { // from getOptions
												$xquery .= ' let $e := for $node in ';
//												if ($howMany) $xquery .= ' subsequence(';
												$xquery .= ' xmldb:document("';
												$xquery .= $xml_resource.'")/tei:TEI/tei:text/tei:*'.$context.' ';
//												if ($howMany) $xquery .= ', '.$startAt.', '.$howMany.' ) ';
												$xquery .= ' return ';
												if (false) {
													$xquery .= ' $node ';
													$xquery .= ' return $e ';
												} else {
													$xquery .= ' if ($node/node()) ';
													$xquery .= ' then ';
													$xquery .= ' ("<item><", local-name($node), " xmlns=&quot;", namespace-uri($node), "&quot;", for $att in $node/@* return (" ", local-name($att), "=&quot;", $att, "&quot;"), ">", "</", local-name($node), "></item>") ';
													$xquery .= ' else ';
													$xquery .= ' let $what := if (/id($node)) then tokenize(tokenize($node, "\s"), "\s") else $node ';
													$xquery .= ' for $item in distinct-values( ';
													$xquery .= ' for $token in $what ';
													$xquery .= ' let $include := if ($node/node() or ('.!$last_val.') or local-name($node) != "'.$last_attr.'") then true() else contains($token, tokenize("'.$match.'", "\s")) ';
													$xquery .= ' return if ($include) then $token else () ';
													$xquery .= ' ) ';
													if ($jolly) {
														$xquery .= ' return substring($item,1,'.$jolly.') ';
													} else {
														$xquery .= ' return $item ';
												 };
												 $xquery .= ' return ';
													if ($howMany) $xquery .= ' for $final in subsequence(';
													$xquery .= ' if (matches($e, "<\w+")) then $e else for $x in distinct-values($e) order by $x return <item>{$x}</item> ';
													if ($howMany) $xquery .= ', '.$startAt.', '.$howMany.' ) return $final ';
												};
										} else {
												$xquery .= ' let $base := xmldb:document("'.$xml_resource.'")/tei:TEI/tei:text';
												$xquery .= ' for $node in ';
												if ($howMany) $xquery .= ' subsequence(';
												$xquery .= ' $base/tei:*'.$context.' ';
												if ($howMany) $xquery .= ', '.$startAt.', '.$howMany.' ) ';
												$xquery .= ' ';
												if ($justRefs) {
													$xquery .= ' let $block := $node ';
													$xquery .= ' let $block_attrs := for $att in $block/@* return (" ", name($att), "=&quot;", string($att), "&quot;") ';
													$xquery .= ' return ';
													$xquery .= ' ("<", local-name($block), " xmlns=&quot;", namespace-uri($block), "&quot;", for $att in $block/@* return (" ", local-name($att), "=&quot;", $att, "&quot;"), ">" ';
													$xquery .= ', "??_undefined_context_??"';
													$xquery .= ', "</", local-name($block), ">") ';
												} else {
													$xquery .= ' let $node := if ($node[self::tei:div]) then $node/child::*[. >> $node//tei:pb[1]][1] else if ($node[self::tei:pb]) then $node/following-sibling::*[. >> $node][1] else $node ';
													$xquery .= ' let $parent := tei:getBlock($node) ';
													$xquery .= ' let $ms1 := ($parent//tei:pb[. << $node])[position()=last()] ';
													$xquery .= ' let $ms2 := (for $pb in $parent//tei:pb[. >> $ms1] order by $pb/position() return $pb)[1]';
													$xquery .= ' let $block := tei:milestone-chunk($ms1, $ms2, $parent) ';
													$xquery .= ' return ';
													$xquery .= ' $block ';
												};
											};
// getDebugFor($context);
// getDebugFor($xquery);
											$result = $this->_db->xquery(DCTL_XQUERY_BASE.$xquery);
											$resultXML = (array) $result["XML"];
											foreach ($resultXML as $node) {
												$db_resource .= $node;
											};
// getDebugFor($db_resource);
											$this->_get_package_record ($justRefs, $xml_resource, &$resList[$key4package]);
											$resList[$key4package]['xquery'] = htmlentities($context);
											if ($resList[$key4package]['ref'] != '') {
												if ($parsed['locator'] != '') $resList[$key4package]['ref'] .= DB_PATH_SEPARATOR.$parsed['locator'];
											};
											if (preg_match('/\w+/', $db_resource)) {
												$resList[$key4package]['check'] = count($resultXML);
											};
											if ($asOptions) {
												$resList[$key4package]['kind'] = "list";
												$resList[$key4package]['list'] = $db_resource;
											} else {
												$resList[$key4package]['kind'] = "tei";
												$resList[$key4package]['fragment'] = $db_resource;
											};
										};
									};
								};
       };
							break;
					// · · · · · · · · · · · · · · · · · · · · · · · · · · · · · · · ·
							case 'img': {
								$parsed['query'] = $parsed['locator'];
								// | media -> img://coll-pippero.pdf, img://coll/pippero.pdf
								$parsed['package'] = $parsed['collection'].DCTL_RESERVED_INFIX.$parsed['package'];
								$parsed['collection'] = '';
								if ($parsed['query'] != '') {
									$parsed['package'] .= DCTL_RESERVED_INFIX.$parsed['query'];
									$parsed['query'] = '';
								};
								$resList[0]['kind'] = "media";
								$resList[0]['ref'] = '';
								$resList[0]['icon'] = '';
								$resList[0]['file'] = '';
								$hi = DCTL_DATA_PATH.$this->_db_publish_path.DCTL_MEDIA_BIG.$parsed['package'];
								if (is_file($hi)) {
									$lo = DCTL_DATA_PATH.$this->_db_publish_path.DCTL_MEDIA_SML.$parsed['package'];
									if (! is_file($lo)) {
										makePreview (DCTL_MEDIA_SML, $hi);
									};
									$resList[0]['ref'] = $parsed['scheme'].'://'.$parsed['package'];
									$resList[0]['icon'] = $this->_fs_publish_path.DCTL_MEDIA_SML.$parsed['package'];
									$resList[0]['file'] = $this->_fs_publish_path.DCTL_MEDIA_BIG.$parsed['package'];
								};
							};
							break;
						};
					};
					break;
					default:
						$resList[0]['kind'] = "url";
						$resList[0]['ref'] = $resource;
					break;
				};
				$docList = array_merge($docList, $resList);
			};
			if (! $asOptions) {
				// wraps results
    return $this->_resources_to_xml($docList);
			} else {
				// raw results
    return $docList;
			};
		}
		// +----------------------------------------------------------------------+
		protected function _resources_to_xml($resourceList, $recursion=false) {
			// | convert record to xml
			$return = '';
			if (! is_array($resourceList)) $resourceList = explode(',', $resourceList);
			if (! $recursion) {
			 $return .= $this->_xml_header.'<dctl>';
			};
   foreach ($resourceList as $resource) {
 			if (! is_array($resource)) $resource = explode(',', $resource);
			 if (! empty($resource['ref'])) {
					$return .= '<resource>';
					foreach($resource as $k=>$v) {
						if (is_array($v)) {
							$v = $this->_resources_to_xml($v, true);
						};
						$return .= '<'.$k.'>'.$v.'</'.$k.'>';
					};
					$return .= '</resource>';
				};
			};
			if (! $recursion) {
			 $return .= '</dctl>';
			};
   return $return;
		}
		// +----------------------------------------------------------------------+
	};
	// +----------------------------------------------------------------------+
	// | END OF MAIN CLASS DEFINITION
	// +----------------------------------------------------------------------+
	// |
	// +----------------------------------------------------------------------+
	// | RETRIEVER CLASS DEFINITION
	// +----------------------------------------------------------------------+
	class dCTLRetriever extends dCTL {
		protected function __construct() {
			parent::__construct();
		}
	// +----------------------------------------------------------------------+
	};
	// +----------------------------------------------------------------------+
	// | END OF RETRIEVER CLASS DEFINITION
	// +----------------------------------------------------------------------+

?>
